# `@next/env`

Next.js' util for loading dotenv files in with the proper priorities
