export { _ as default } from "../esm/_construct.js";
