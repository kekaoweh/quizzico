export { _ as default } from "../esm/_create_super.js";
