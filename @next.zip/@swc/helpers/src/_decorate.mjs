export { _ as default } from "../esm/_decorate.js";
