export { _ as default } from "../esm/_new_arrow_check.js";
