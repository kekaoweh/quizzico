export { _ as default } from "../esm/_write_only_error.js";
