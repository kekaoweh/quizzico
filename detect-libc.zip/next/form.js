module.exports = require('./dist/client/form')
