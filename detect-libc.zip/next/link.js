module.exports = require('./dist/client/link')
