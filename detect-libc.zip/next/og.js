module.exports = require('./dist/server/og/image-response')
