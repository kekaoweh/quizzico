module.exports = require('./dist/babel').macro()
