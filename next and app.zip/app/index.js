// pages/index.js
import { useState } from 'react';
import axios from 'axios';

export default function Home() {
    const [file, setFile] = useState(null);
    const [quiz, setQuiz] = useState('');

    const handleFileChange = (e) => {
        setFile(e.target.files[0]);
    };

    const handleGenerateQuiz = async () => {
        if (!file) {
            alert('Please upload a PDF file');
            return;
        }

        const formData = new FormData();
        formData.append('pdf', file);

        try {
            const response = await axios.post('http://127.0.0.1:5000/generate-quiz', formData, {
                headers: { 'Content-Type': 'multipart/form-data' },
            });
            setQuiz(response.data.quiz);
        } catch (error) {
            console.error('Error generating quiz:', error);
        }
    };

    return (
        <div style={{ padding: '20px' }}>
            <h1>PDF Quiz Generator</h1>
            <input type="file" accept="application/pdf" onChange={handleFileChange} />
            <button onClick={handleGenerateQuiz}>Generate Quiz</button>
            {quiz && (
                <div>
                    <h2>Generated Quiz:</h2>
                    <pre>{quiz}</pre>
                </div>
            )}
        </div>
    );
}
